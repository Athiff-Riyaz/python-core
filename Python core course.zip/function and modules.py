#function
print("hello world!")
range(2,20)
str(12)
range(10,20,3)
